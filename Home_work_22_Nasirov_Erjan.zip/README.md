# Bootstrap
## Тренировочный макет

Чтобы начать работать:
1. Склонируйте репозиторий выполнив команду в консоли `git clone https://github.com/Commondore/bootstrap-example.git`
2. Установите необходимые npm пакеты, команда `npm install` в консоли в папке с проектом
3. Запустите компилятор sass командой `sass --watch sass:css`
